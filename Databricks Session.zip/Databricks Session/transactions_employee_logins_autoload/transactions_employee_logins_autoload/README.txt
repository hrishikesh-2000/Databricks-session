Synthetic CSV files for Databricks Auto Loader demo
Target table: transactions.employee.logins

Folder layout: day=YYYY-MM-DD/logins_XX.csv

Schema (CSV header):
  - login_id
  - employee_id
  - login_ts
  - logout_ts
  - ip_address
  - device
  - city
  - auth_method
  - status

Notes:
  * File 4 contains one deliberate duplicate row (same login_id) to demonstrate dedupe/idempotency if you want.
