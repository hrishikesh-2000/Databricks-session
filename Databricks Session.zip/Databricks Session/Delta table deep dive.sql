-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark

-- COMMAND ----------

CREATE CATALOG DEMO
MANAGED LOCATION 'abfss://data@sadbdemoi.dfs.core.windows.net/';


CREATE SCHEMA DEMO.FACTS;


CREATE OR REPLACE TABLE DEMO.FACTS.SALES (
  id INT,
  product STRING,
  price DECIMAL(5,2),
  quantity INT,
  sale_date DATE
)


-- COMMAND ----------

INSERT INTO DEMO.FACTS.SALES (id, product, price, quantity, sale_date) VALUES
  (1, 'Widget', 19.99, 3, DATE '2026-01-15'),
  (2, 'Gadget', 29.50, 2, DATE '2026-01-20'),
  (3, 'Thingamajig', 9.75, 5, DATE '2026-01-25'),
  (4, 'Doodad', 14.30, 1, DATE '2026-01-28'),
  (5, 'Gizmo', 23.45, 4, DATE '2026-01-27');

-- COMMAND ----------

select * from DEMO.FACTS.SALES;

-- COMMAND ----------

update DEMO.FACTS.SALES
  set price = price * 1.10
  where sale_date >= '2026-01-27';


select * from DEMO.FACTS.SALES

-- COMMAND ----------

describe history DEMO.FACTS.SALES;

-- COMMAND ----------

select * from demo.facts.sales version as of 2;

-- COMMAND ----------

restore table demo.facts.sales to version as of 2;

-- COMMAND ----------

describe history demo.facts.sales;

-- COMMAND ----------

describe table extended demo.facts.sales;

-- COMMAND ----------

-- DBTITLE 1,Cell 11
DESCRIBE DETAIL demo.facts.sales;

-- COMMAND ----------

create external table demo.facts.sales_external
location 'abfss://data@sadbdemoi.dfs.core.windows.net/sales_external'
as select * from demo.facts.sales


-- COMMAND ----------

select * from demo.facts.sales_external;

-- COMMAND ----------

update demo.facts.sales_external
  set price = 100.0
  where product = 'Gadget';

-- COMMAND ----------

describe detail demo.facts.sales_external;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.ls("abfss://data@sadbdemoi.dfs.core.windows.net/sales_external/"))

-- COMMAND ----------

update demo.facts.sales_external
  set price = 120.0
  where product = 'Widget';

-- COMMAND ----------

restore table demo.facts.sales_external to version as of 3

-- COMMAND ----------

describe history demo.facts.sales_external;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS DEMO.FACTS.SALES_parquet (
  id INT,
  product STRING,
  price DECIMAL(5,2),
  quantity INT,
  sale_date DATE
)
using parquet
location
'abfss://data@sadbdemoi.dfs.core.windows.net/sales_parquet'

-- COMMAND ----------

INSERT INTO DEMO.FACTS.sales_parquet (id, product, price, quantity, sale_date) VALUES
  (1, 'Widget', 19.99, 3, DATE '2026-01-15'),
  (2, 'Gadget', 29.50, 2, DATE '2026-01-20'),
  (3, 'Thingamajig', 9.75, 5, DATE '2026-01-25'),
  (4, 'Doodad', 14.30, 1, DATE '2026-01-28'),
  (5, 'Gizmo', 23.45, 4, DATE '2026-01-27');

-- COMMAND ----------



-- COMMAND ----------

REFRESH TABLE demo.facts.sales_parquet;

-- COMMAND ----------

select * from demo.facts.sales_parquet;

-- COMMAND ----------

update demo.facts.sales_parquet
  set price = 120.0
  where product = 'Widget';

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df = spark.sql("select * from demo.facts.sales_parquet")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql.functions import lit, col, when
-- MAGIC temp_df = df.withColumn('price', when(col('product') == 'Widget', lit(0)).otherwise(col('price')))
-- MAGIC
-- MAGIC display(temp_df)
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC temp_df.write.format('parquet').mode('overwrite').option('path','abfss://data@sadbdemoi.dfs.core.windows.net/sales_parquet_new').saveAsTable('demo.facts.sales_parquet_new')

-- COMMAND ----------


select * from demo.facts.sales_parquet_new;

-- COMMAND ----------

drop table sales_parquet_new

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df = spark.table("demo.facts.sales_parquet")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC df = df.persist()
-- MAGIC df.count()     # forces a full materialized snapshot
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC df.createOrReplaceTempView("tmp_sales_snapshot")
-- MAGIC snapshot_df = spark.sql("SELECT * FROM tmp_sales_snapshot")
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC from pyspark.sql.functions import when, col, lit
-- MAGIC
-- MAGIC temp_df = df.withColumn(
-- MAGIC     "price",
-- MAGIC     when(col("product") == "Widget", lit(0)).otherwise(col("price"))
-- MAGIC )
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC temp_df.write.format("parquet").mode("overwrite").option("path","abfss://data@sadbdemoi.dfs.core.windows.net/sales_parquet").saveAsTable('demo.facts.sales_parquet')
-- MAGIC
-- MAGIC

-- COMMAND ----------

select * from demo.facts.sales_parquet;