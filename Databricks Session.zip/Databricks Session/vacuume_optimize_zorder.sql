-- Databricks notebook source
create catalog transactions
managed location 'abfss://data@sadbdemo.dfs.core.windows.net/transactions'

-- COMMAND ----------

drop schema transactions.employee cascade;

-- COMMAND ----------

create schema transactions.employee
managed location 'abfss://data@sadbdemo.dfs.core.windows.net/'

-- COMMAND ----------

create table transactions.employee.salary (
    id int,
    name string,
    salary double
)

-- COMMAND ----------

insert into transactions.employee.salary (id, name, salary) values
    (1, 'Alice Smith', 75000.00),
    (2, 'Bob Johnson', 82000.50),
    (3, 'Carol Lee', 91000.00),
    (4, 'David Kim', 67000.25),
    (5, 'Eva Brown', 99000.00),
    (6, 'Frank White', 72000.75),
    (7, 'Grace Green', 88000.00),
    (8, 'Henry Black', 94000.50),
    (9, 'Ivy Young', 81000.00),
    (10, 'Jack King', 86000.00);

-- COMMAND ----------

select * from transactions.employee.salary 

-- COMMAND ----------

insert into transactions.employee.salary (id, name, salary) values
    (11, 'Liam Turner', 78000.00),
    (12, 'Mia Clark', 83000.50),
    (13, 'Noah Scott', 92000.00),
    (14, 'Olivia Adams', 69000.25),
    (15, 'Paul Walker', 97000.00);

-- COMMAND ----------

optimize transactions.employee.salary
zorder by (id)

-- COMMAND ----------

SET spark.databricks.delta.retentionDurationCheck.enabled = false

-- COMMAND ----------

vacuum transactions.employee.salary retain 0 hours dry run

-- COMMAND ----------

vacuum transactions.employee.salary retain 0 hours

-- COMMAND ----------

describe history transactions.employee.salary;

-- COMMAND ----------

create table transactions.employee.trips
as select * from samples.nyctaxi.trips

-- COMMAND ----------

select * from transactions.employee.trips

-- COMMAND ----------

alter table transactions.employee.trips cluster by (pickup_zip)

-- COMMAND ----------

describe history transactions.employee.trips 