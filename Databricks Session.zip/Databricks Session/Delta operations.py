# Databricks notebook source
# MAGIC %sql
# MAGIC --SCD1
# MAGIC Create catalog if not exists transactions;

# COMMAND ----------

# MAGIC %sql
# MAGIC Create schema transactions.employee;
# MAGIC Create table transactions.employee.salary (
# MAGIC   id int, 
# MAGIC   name string, 
# MAGIC   dept string, 
# MAGIC   salary int);

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO transactions.employee.salary (id, name, dept, salary) VALUES
# MAGIC   (1, 'Alice Smith', 'HR', 60000),
# MAGIC   (2, 'Bob Johnson', 'Finance', 65000),
# MAGIC   (3, 'Carol Lee', 'Engineering', 90000),
# MAGIC   (4, 'David Kim', 'Marketing', 70000),
# MAGIC   (5, 'Eva Brown', 'Sales', 72000),
# MAGIC   (6, 'Frank White', 'Engineering', 95000),
# MAGIC   (7, 'Grace Green', 'Finance', 67000),
# MAGIC   (8, 'Henry Black', 'HR', 61000),
# MAGIC   (9, 'Ivy Young', 'Sales', 73000),
# MAGIC   (10, 'Jack Turner', 'Marketing', 71000);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from transactions.employee.salary;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history transactions.employee.salary;
# MAGIC restore table transactions.employee.salary version as of 8;

# COMMAND ----------

# MAGIC %sql
# MAGIC create  or replace table transactions.employee.salary_updates
# MAGIC as select * from transactions.employee.salary;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from transactions.employee.salary_updates

# COMMAND ----------

# MAGIC %sql
# MAGIC update transactions.employee.salary_updates
# MAGIC set salary = 110000,
# MAGIC     start_dte = '2026-09-30',
# MAGIC     end_dte = '9999-12-31'
# MAGIC where id = 4

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into transactions.employee.salary as tgt
# MAGIC using transactions.employee.salary_updates as src
# MAGIC on  tgt.id = src.id and tgt.end_dte <= src.start_dte and tgt.salary != src.salary
# MAGIC when matched then
# MAGIC   update set
# MAGIC     tgt.end_dte = src.start_dte;
# MAGIC
# MAGIC     -- 4	David Kim	Marketing	80000	2025-12-30	2026-08-31
# MAGIC     -- 4	David Kim	Marketing	100000	2026-08-31	9999-12-31
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into transactions.employee.salary as tgt
# MAGIC using transactions.employee.salary_updates as src
# MAGIC on  tgt.id = src.id and tgt.salary = src.salary and tgt.end_dte = src.end_dte
# MAGIC when not matched
# MAGIC   then insert *;

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- SCD type 1
# MAGIC merge into transactions.employee.salary as tgt
# MAGIC using transactions.employee.salary_updates as src
# MAGIC on tgt.start_dte >= src.start_dte and tgt.salary != src.salary
# MAGIC when matched then
# MAGIC   update set
# MAGIC     tgt.end_dte = src.start_dte;
# MAGIC
# MAGIC
# MAGIC
# MAGIC merge into transactions.employee.salary as tgt
# MAGIC using transactions.employee.salary_updates as src
# MAGIC on  tgt.id = src.id and tgt.salary = src.salary
# MAGIC when not matched
# MAGIC   then insert *;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table transactions.employee.salary
# MAGIC add column start_dte date, end_dte date

# COMMAND ----------

# DBTITLE 1,Cell 10
# MAGIC %sql
# MAGIC MERGE INTO transactions.employee.salary AS target
# MAGIC USING (
# MAGIC   SELECT 
# MAGIC     id,
# MAGIC     date_add(current_date(), cast(rand() * -100 as int)) as new_start_dte,
# MAGIC     date_add(date_add(current_date(), cast(rand() * -100 as int)), cast(rand() * 365 as int)) as new_end_dte
# MAGIC   FROM transactions.employee.salary
# MAGIC ) AS source
# MAGIC ON target.id = source.id
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     target.start_dte = source.new_start_dte,
# MAGIC     target.end_dte = source.new_end_dte

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SCD type 2
# MAGIC /*
# MAGIC
# MAGIC   When ID matches
# MAGIC     1. start date of new record should be end of previous
# MAGIC     2. New record with new end date should be inserted
# MAGIC
# MAGIC */
# MAGIC
# MAGIC merge into transactions.employee.salary as tgt
# MAGIC using transactions.employee.salary_updates as src
# MAGIC on tgt.id = src.id and tgt.salary = src.salary
# MAGIC when not matched then
# MAGIC   update set
# MAGIC     tgt.end_dte = src.start_dte