-- Databricks notebook source
DROP TABLE `transactions`.`employee`.`salary_ext`

-- COMMAND ----------

CREATE OR REPLACE TABLE transactions.employee.salary_ext (
  id int, 
  name string, 
  dept string, 
  salary int)

LOCATION 'abfss://data@sadbdemo.dfs.core.windows.net/salary_ext'

-- COMMAND ----------

alter table transactions.employee.salary_ext set tblproperties ('delta.enableDeletionVectors' = false)

-- COMMAND ----------

INSERT INTO transactions.employee.salary_ext (id, name, dept, salary) VALUES
  (1, 'Alice Smith', 'HR', 60000),
  (2, 'Jane Doe', 'HR', 80000),
  (3, 'Jon Doe', 'MARKETING', 80000);

-- COMMAND ----------

select * from transactions.employee.salary_ext;

-- COMMAND ----------

describe history transactions.employee.salary_ext;

-- COMMAND ----------

INSERT INTO transactions.employee.salary_ext (id, name, dept, salary) VALUES
  (4, 'Jone Doe', 'Marketing', 70000);

-- COMMAND ----------

delete from transactions.employee.salary_ext where id = 1

-- COMMAND ----------

alter table transactions.employee.salary_ext set tblproperties ('delta.enableDeletionVectors' = true)

-- COMMAND ----------

INSERT INTO transactions.employee.salary_ext (id, name, dept, salary) VALUES
  (12, 'Jane Doe', 'Marketing', 70000);

-- COMMAND ----------

delete from transactions.employee.salary_ext where id = 1

-- COMMAND ----------

delete from transactions.employee.salary_ext where id = 8

-- COMMAND ----------

SHOW TBLPROPERTIES transactions.employee.salary_ext